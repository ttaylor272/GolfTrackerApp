﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GolfTrackerLibrary.Models
{
    class LocationModel
    {
        // GrabCourse method
        public string LocationName  { get; set; }
        public string LocationState { get; set; }
        public string LocationCity { get; set; } 

      
    }
}
