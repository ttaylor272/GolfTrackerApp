using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace GolfTrackerTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
